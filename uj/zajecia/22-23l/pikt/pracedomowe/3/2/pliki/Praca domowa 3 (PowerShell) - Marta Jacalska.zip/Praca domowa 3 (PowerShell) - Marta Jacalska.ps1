# Poprawki:
# - jeden skrypt dla wszystkich plików HTML zamiast trzech oddzielnych
# - użycie operatora -split zamiast -replace do pozbycia się tagów

$PlikiHtml = Get-ChildItem -Path "*.html"

$PlikiHtml | forEach-Object {
	$Assignment = Get-Content $_

	$Assignment = $Assignment | Select-String -Pattern "<h1>","<h2>","<li>","<p>"

	$Assignment = $Assignment -split "`t" -split "<h1>" -split "</h1>" -split "<h2>" -split "</h2>" -split "<li>" -split "</li>" -split "<p>" -split "</p>"

	$Assignment | Sort-Object -Property Length | Out-File -Filepath ($_.BaseName + ".txt")
}

Pause
