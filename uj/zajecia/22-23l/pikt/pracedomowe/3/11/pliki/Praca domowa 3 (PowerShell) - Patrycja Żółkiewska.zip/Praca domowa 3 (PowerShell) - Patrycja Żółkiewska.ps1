# Poprawki:
# - jeden skrypt dla wszystkich plików HTML zamiast trzech oddzielnych
# - dodanie pauzy na końcu

$PlikiHtml = Get-ChildItem -Path "*.html"

$PlikiHtml | ForEach-Object {
	$Zad1 = Get-Content -Path $_ -Raw
	$Elem = Select-String -InputObject $Zad1 -AllMatches -Pattern ">(.*?)<"
	$All = foreach ($Elem1 in $Elem.Matches) {
		$Elem1.Groups[1].Value
	}
	$All = $All | Where-Object { $_ -ne "" }
	$All | Sort-Object { $_.Length } | Out-File -FilePath ($_.BaseName + ".txt")
}

Pause
