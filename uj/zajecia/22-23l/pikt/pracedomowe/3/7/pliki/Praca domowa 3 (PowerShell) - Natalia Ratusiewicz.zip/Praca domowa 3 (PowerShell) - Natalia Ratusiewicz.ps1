$Html = Get-ChildItem -Path "*.html"

$Html | ForEach-Object {
	$Text = Get-Content -Path $_
	$All = $Text | Select-String -Pattern "<.*>.*</.*>"
	$Clean = $All -replace "<.*?>", "" -replace "`t", "" -match "."
	$Clean | Sort-Object -Property Length | Set-Content -Path ($_.Basename + ".txt")
}

Pause
