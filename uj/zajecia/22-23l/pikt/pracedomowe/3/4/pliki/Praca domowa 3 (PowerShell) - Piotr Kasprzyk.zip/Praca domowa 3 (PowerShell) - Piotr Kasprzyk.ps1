# Poprawki:
# - jeden skrypt dla wszystkich plików HTML zamiast trzech oddzielnych
# - zastosowanie dwóch operatorów -replace jeden po drugim
# - zapis operatorów małą literą
# - dodanie pauzy na końcu

$PlikiHtml = Get-ChildItem -Path "*.html"

$PlikiHtml | forEach-Object {
	$PlikHtml = Get-Content -Path $_ | Select-String -Pattern "<.*>.*<.*>"
	$PlikHtml = $PlikHtml -replace "<.*?>", "" -replace "`t","" | Sort-Object -Property Length | Set-Content -Path ($_.BaseName + ".txt")
}

Pause
