# Poprawki:
# - jeden skrypt dla wszystkich plików HTML zamiast trzech oddzielnych
# - zapis zmiennych przy pomocy PascalCase
# - dodanie pauzy na końcu

$PlikiHtml = Get-ChildItem -Path "*.html"

$PlikiHtml | ForEach-Object {
	$Html = Get-Content -Path $_
	$Html
	$Elements = $Html | Select-String -Pattern "<(h[1-6]|li|p)[^>]*>[^<]*</\1>"
	$Elements
	$CleanedElements = $Elements | ForEach-Object { $_.Matches.Value -replace "<[^>]*>" }
	$CleanedElements
	$SortedElements = $CleanedElements | Sort-Object { $_.Length }
	$SortedElements
	$SortedElements | Out-File -FilePath ($_.BaseName + ".txt")
}

Pause
