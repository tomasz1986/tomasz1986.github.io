# Poprawki:
# - zmienne zapisane za pomocą PascalCase
# - jeden skrypt dla wszystkich plików HTML zamiast trzech oddzielnych
# - Where-Object zamiast aliasu "where"
# - usunięty zbędny parametr AllMatches
# - dodana pauza na końcu

$PlikiXml = Get-ChildItem -Path "*.html"
$PlikiXml

$PlikiXml | forEach-Object {
	$PlikXml = Get-Content -Path $_
	$PlikXml

	$Treść = Select-String -InputObject $PlikXml -Pattern ">(.*?)<"
	$Treść

	$CleanText = $PlikXml -replace "<[^<>]+>",""
	$CleanText

	$Sorted = $CleanText | Sort-Object -Property Length
	$Sorted

	$Trimed = $Sorted.Trim() | Where-Object { $_ -ne "" }
	$Trimed

	$Trimed | Out-File -FilePath ($_.BaseName + ".txt")
}

Pause
