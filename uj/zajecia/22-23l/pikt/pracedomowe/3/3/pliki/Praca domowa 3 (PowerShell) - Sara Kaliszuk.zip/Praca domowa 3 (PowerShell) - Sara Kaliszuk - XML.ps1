# Poprawki:
# - zmienne, polecenia i parametry zapisane za pomocą PascalCase
# - forEach-Object zamiast aliasu "foreach"
# - usunięcie zbędnego polecenia Write-Output
# - dodanie pauzy na końcu

$Zadanie1 = Get-Content -Path "Praca domowa 2 (HTML) - Sara Kaliszuk - XML.html"
$Niepuste1 = $Zadanie1 | Select-String "<li>","<h.>"
$Clean1 = $Niepuste1 | Select-String "<li>","<h.>" | Select-Object -ExpandProperty Line
$Clean1 = $Clean1 -replace "<[^>]+>"
$Niepuste1 = $Clean1 | Select-String "<li>","<h.>" | forEach-Object {$_.line}
$Sorted1 = $Clean1 | Sort-Object -Property Length
$Sorted1 | Set-Content -Path "Praca domowa 2 (HTML) - Sara Kaliszuk - XML.txt"
