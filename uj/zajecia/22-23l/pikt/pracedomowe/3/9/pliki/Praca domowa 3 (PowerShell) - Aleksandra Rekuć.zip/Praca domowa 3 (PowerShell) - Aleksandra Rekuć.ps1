# Poprawki:
# - jeden skrypt dla wszystkich plików HTML zamiast trzech oddzielnych

$PlikiHtml = Get-ChildItem -Path "*.html"

$PlikiHtml | ForEach-Object {
	$Treść = Get-Content -Path $_

	# Połącz do jednej linii, usuń komentarz, zamień <br> na spacje, usuń początkowe i końcowe tagi z <a>, usuń tabulatory, podziel na linie wg tagów, usuń końcowe spacje, pozostaw tylko niepuste linie.
	$Treść = $Treść -join "" -replace "<!--.*?-->","" -replace "<br>"," " -replace "<a .+?>","" -replace "</a>","" -replace "`t","" -split "<.+?>" -replace " +$","" -match ".+"

	$Treść | Sort-Object -Propert Length | Set-Content -Path ($_.BaseName + ".txt")
}

Pause
